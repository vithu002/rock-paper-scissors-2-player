// Static viewer for the Python project files (no game logic here).
// The real game is app.py — run it with: streamlit run app.py
import { useState } from "react";
import appPy from "../app.py?raw";
import reqs from "../requirements.txt?raw";
import readme from "../README.md?raw";
import tests from "../tests/test_game.py?raw";
import gitignore from "../.gitignore?raw";
import config from "../.streamlit/config.toml?raw";

const FILES: Record<string, string> = {
  "app.py": appPy,
  "requirements.txt": reqs,
  "README.md": readme,
  "tests/test_game.py": tests,
  ".gitignore": gitignore,
  ".streamlit/config.toml": config,
};

export default function App() {
  const [file, setFile] = useState("app.py");
  return (
    <div className="min-h-screen bg-[#050816] p-4 text-slate-200 md:p-8">
      <h1 className="bg-gradient-to-r from-cyan-400 via-white to-orange-400 bg-clip-text text-center text-3xl font-black text-transparent md:text-5xl">
        Rock Paper Scissors — 2 Player
      </h1>
      <p className="mt-2 text-center text-xs tracking-[0.35em] text-slate-500">
        PYTHON · STREAMLIT PROJECT FILES
      </p>
      <p className="mx-auto mt-4 max-w-2xl text-center text-sm text-slate-400">
        The game is a Python Streamlit app. Run{" "}
        <code className="text-cyan-300">streamlit run app.py</code> locally or deploy it to
        Streamlit Community Cloud (see README.md).
      </p>
      <div className="mx-auto mt-6 flex max-w-5xl flex-wrap gap-2">
        {Object.keys(FILES).map((f) => (
          <button
            key={f}
            onClick={() => setFile(f)}
            className={`rounded-lg border px-3 py-1.5 text-sm font-semibold ${
              f === file ? "border-cyan-400 text-cyan-300" : "border-slate-700 text-slate-400 hover:text-white"
            }`}
          >
            {f}
          </button>
        ))}
        <button
          onClick={() => {
            const blob = new Blob([FILES[file]], { type: "text/plain" });
            const a = document.createElement("a");
            a.href = URL.createObjectURL(blob);
            a.download = file.split("/").pop()!;
            a.click();
          }}
          className="ml-auto rounded-lg bg-orange-500 px-3 py-1.5 text-sm font-bold text-white hover:bg-orange-400"
        >
          Download {file.split("/").pop()}
        </button>
      </div>
      <pre className="mx-auto mt-3 max-h-[70vh] max-w-5xl overflow-auto rounded-xl border border-slate-800 bg-slate-950 p-4 text-xs leading-relaxed">
        {FILES[file]}
      </pre>
    </div>
  );
}

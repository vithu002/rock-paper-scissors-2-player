# ✊✋✌️ Rock Paper Scissors — 2 Player

A local two-player Rock Paper Scissors game (two people, one device) built **only with Python + Streamlit + custom CSS**. College Python mini project.

## Features
- Dark navy gaming look: cyan Player 1 panel, orange Player 2 panel
- Hidden moves: Player 1's choice shows as **?** / "LOCKED IN ✔" until Player 2 has chosen
- Both choices are revealed together, and the winner gets 1 point (draws give no points)
- Round counter, draw counter, and target display
- **First to 5** toggle with a match-winner banner. Moves are blocked until a new match starts
- Next Round, Reset Game, and Quit Game controls, plus a round history
- Responsive layout for phones, tablets, and desktops

## Project structure
```
app.py                 # the whole game (logic + UI)
requirements.txt       # Python dependencies
.streamlit/config.toml # dark theme
tests/test_game.py     # automated tests (pytest + Streamlit AppTest)
README.md
.gitignore
```

## How the code works
| Function | Purpose |
|---|---|
| `initialize_game()` | Creates any missing values in `st.session_state` |
| `determine_winner()` | Applies the rules using the `BEATS` dictionary |
| `play_round()` | Stores P1's secret move, then scores the round on P2's move |
| `next_round()` | Clears the choices and keeps the scores (only allowed after a reveal) |
| `reset_game()` | Clears scores, draws, choices, and history |
| `quit_game()` | Shows the goodbye screen |
| `main()` | Builds the Streamlit page |

A `phase` value (`p1 → p2 → reveal → p1 …`, or `match_over` / `quit`) controls which actions are allowed. Moves are only accepted in `p1`/`p2`, and scoring only happens once, on the `p2 → reveal` step. This means a double click can't score a round twice.

## Run locally
```bash
# 1. (optional) create a virtual environment
python -m venv venv
# Windows: venv\Scripts\activate     macOS/Linux: source venv/bin/activate

# 2. install dependencies
pip install -r requirements.txt

# 3. start the game
streamlit run app.py
```
Open http://localhost:8501 in your browser.

## Run the tests
```bash
pip install pytest
python -m pytest -v
```
The tests cover: Rock beats Scissors, Scissors beats Paper, Paper beats Rock, draws, a score updating exactly once per round, Next Round keeping the scores, Reset clearing everything, the First-to-5 match ending, Player 2 not seeing Player 1's move, and the app running without errors.

## Deploy to GitHub
1. Sign in at https://github.com and click **New repository**.
2. Name it, for example `rock-paper-scissors-2p`, set it to **Public**, and click **Create repository**.
3. **Option A (browser):** Click **uploading an existing file** and drag in `app.py`, `requirements.txt`, `README.md`, `.gitignore`, and the `tests` folder. Then click **Commit changes**.
   The `.streamlit` folder is hidden on some computers. To add it, click **Add file → Create new file**, name it `.streamlit/config.toml`, paste its contents, and commit.
4. **Option B (command line):**
   ```bash
   git init
   git add app.py requirements.txt README.md .gitignore .streamlit tests
   git commit -m "Rock Paper Scissors 2 Player"
   git branch -M main
   git remote add origin https://github.com/<your-username>/rock-paper-scissors-2p.git
   git push -u origin main
   ```

## Deploy to Streamlit Community Cloud
1. Go to https://share.streamlit.io and **sign in with GitHub** (allow access when asked).
2. Click **Create app** and choose **Deploy a public app from GitHub**.
3. Fill in:
   - **Repository:** `<your-username>/rock-paper-scissors-2p`
   - **Branch:** `main`
   - **Main file path:** `app.py`
   - **App URL:** pick a name, for example `rps-2player`
4. (Optional) Under **Advanced settings**, set Python to 3.11 or later.
5. Click **Deploy**. The first build takes 1–3 minutes.
6. Your public link will look like `https://rps-2player.streamlit.app`. Open it on your phone to test.
7. Every `git push` to `main` redeploys the app automatically.

**Troubleshooting:** If the build fails, open **Manage app → Logs**. Check that `requirements.txt` is in the repo root and that the main file path is exactly `app.py`.

"""
Automated tests for the Rock Paper Scissors game.

Run with:   python -m pytest -v
"""

import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import (  # noqa: E402
    determine_winner, initialize_game, next_round, play_round, reset_game,
)

APP_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "app.py")


def new_state(first_to_5=True):
    state = {}
    initialize_game(state)
    state["first_to_5"] = first_to_5
    return state


# ---------------- Rules ----------------
def test_rock_beats_scissors():
    assert determine_winner("rock", "scissors") == "p1"
    assert determine_winner("scissors", "rock") == "p2"


def test_scissors_beats_paper():
    assert determine_winner("scissors", "paper") == "p1"
    assert determine_winner("paper", "scissors") == "p2"


def test_paper_beats_rock():
    assert determine_winner("paper", "rock") == "p1"
    assert determine_winner("rock", "paper") == "p2"


@pytest.mark.parametrize("choice", ["rock", "paper", "scissors"])
def test_equal_choices_draw(choice):
    assert determine_winner(choice, choice) == "draw"


def test_invalid_choice_rejected():
    with pytest.raises(ValueError):
        determine_winner("lizard", "rock")
    state = new_state()
    assert play_round(state, "spock") is False
    assert state["phase"] == "p1"


# ---------------- Scoring ----------------
def test_score_updates_exactly_once():
    s = new_state()
    play_round(s, "rock")
    play_round(s, "scissors")
    assert (s["p1_score"], s["p2_score"]) == (1, 0)
    # Extra clicks after the reveal must be ignored
    assert play_round(s, "rock") is False
    assert play_round(s, "paper") is False
    assert (s["p1_score"], s["p2_score"]) == (1, 0)
    assert len(s["history"]) == 1


def test_draw_does_not_score():
    s = new_state()
    play_round(s, "paper")
    play_round(s, "paper")
    assert (s["p1_score"], s["p2_score"], s["draws"]) == (0, 0, 1)


def test_next_round_preserves_scores():
    s = new_state()
    play_round(s, "paper")
    play_round(s, "rock")
    assert next_round(s) is True
    assert s["p1_score"] == 1 and s["round"] == 2
    assert s["p1_choice"] is None and s["p2_choice"] is None and s["phase"] == "p1"
    # Next round is not allowed mid-round
    assert next_round(s) is False
    assert s["round"] == 2


def test_reset_clears_everything():
    s = new_state()
    for p1, p2 in [("rock", "scissors"), ("rock", "rock"), ("rock", "paper")]:
        play_round(s, p1)
        play_round(s, p2)
        next_round(s)
    reset_game(s)
    assert s["p1_score"] == s["p2_score"] == s["draws"] == 0
    assert s["round"] == 1 and s["history"] == [] and s["phase"] == "p1"
    assert s["match_winner"] is None


def test_first_to_five_ends_match():
    s = new_state(first_to_5=True)
    for i in range(5):
        play_round(s, "rock")
        play_round(s, "paper")  # P2 wins every round
        if i < 4:
            next_round(s)
    assert s["p2_score"] == 5
    assert s["phase"] == "match_over" and s["match_winner"] == "p2"
    # No more moves or rounds allowed
    assert play_round(s, "rock") is False
    assert next_round(s) is False
    assert s["p2_score"] == 5


def test_without_target_play_continues():
    s = new_state(first_to_5=False)
    for _ in range(7):
        play_round(s, "scissors")
        play_round(s, "paper")
        next_round(s)
    assert s["p1_score"] == 7 and s["match_winner"] is None


# ---------------- UI tests (Streamlit AppTest) ----------------
def _ui():
    from streamlit.testing.v1 import AppTest
    at = AppTest.from_file(APP_PATH, default_timeout=30)
    at.run()
    return at


def _all_markdown(at):
    return " ".join(m.value for m in at.markdown)


def test_app_runs_without_errors():
    at = _ui()
    assert not at.exception
    assert "Rock Paper Scissors — 2 Player" in _all_markdown(at)
    assert "LOCAL DUEL · 2 PLAYERS · 1 DEVICE" in _all_markdown(at)


def test_player2_cannot_see_player1_choice():
    at = _ui()
    at.button(key="btn_scissors").click().run()
    html = _all_markdown(at)
    assert at.session_state["phase"] == "p2"
    assert "Player 2, your turn" in html
    assert "✌️" not in html.split("rps-subtitle")[1].split("banner")[0]  # panels hide it
    assert "LOCKED IN" in html
    assert "SCISSORS" not in html


def test_full_round_in_ui():
    at = _ui()
    at.button(key="btn_rock").click().run()
    at.button(key="btn_scissors").click().run()
    assert not at.exception
    assert at.session_state["p1_score"] == 1
    assert "Player 1 wins the round" in _all_markdown(at)
    # Move buttons are gone after reveal
    keys = [b.key for b in at.button]
    assert "btn_rock" not in keys
    at.button(key="btn_next").click().run()
    assert at.session_state["round"] == 2 and at.session_state["p1_score"] == 1
    at.button(key="btn_quit").click().run()
    assert "Thanks for playing" in _all_markdown(at)
